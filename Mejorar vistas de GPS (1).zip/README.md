
  # Mejorar vistas de GPS

  This is a code bundle for Mejorar vistas de GPS. The original project is available at https://www.figma.com/design/wtUW5WqlG5yDVhmzD1tiw2/Mejorar-vistas-de-GPS.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  